import pyodbc
import logging
import sys

logger = logging.getLogger()

server = 'database-1.cnndpsyrr6sg.us-east-1.rds.amazonaws.com'
database = 'rdsadmin'
port = '1433'
userName = 'admin'
password = 'ROFtQP4YkrzTpN2AfkJa'
try:
	conn = pyodbc.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER=' + server + ';PORT=' + str(port) + ';DATABASE=' + database + ';UID=' + userName + ';PWD=' + password)

except:
	logger.error("ERROR:could not connect to mysql instance")
	sys.exit()
logger.info("SUCCESS")

def handler(event, context):
	crsr = conn.cursor()
	rows = crsr.excute("select @@VERSION").fetchall()
	print(rows)
	logger.info(rows)
	crsr.close()
	conn.close()




